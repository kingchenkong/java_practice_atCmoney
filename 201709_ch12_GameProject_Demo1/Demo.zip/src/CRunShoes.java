
public class CRunShoes extends CBox{

	public CRunShoes() {

	
	
	}

}
